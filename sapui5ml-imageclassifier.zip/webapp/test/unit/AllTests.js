sap.ui.define([
	"demo/sapui5ml-imageclassifier/test/unit/controller/demo.controller"
], function () {
	"use strict";
});